<?php

# Load the rest library when the spark is loaded
$autoload['libraries'] = array('rest');